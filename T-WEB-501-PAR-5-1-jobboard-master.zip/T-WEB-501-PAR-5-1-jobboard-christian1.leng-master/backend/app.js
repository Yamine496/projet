const express = require("express");
const bodyParser = require("body-parser");
const Routes = require("./src/routes/jobBoard.routes");

const app = express();

const port = 8080;

app.use(bodyParser.json());
app.use(Routes);
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.listen(port, () => {
  console.log(`Server ready at port ${port}`);
});
