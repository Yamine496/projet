'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class advertisements extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  };
  advertisements.init({
    contact: DataTypes.STRING,
    contart: DataTypes.STRING,
    full_description: DataTypes.STRING,
    id_recruteur: DataTypes.INTEGER,
    name_companies: DataTypes.STRING,
    name_job: DataTypes.STRING,
    post_description: DataTypes.STRING,
    profil_description: DataTypes.STRING,
    salaire: DataTypes.STRING,
    small_description: DataTypes.STRING,
    ville: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'advertisements',
  });
  return advertisements;
};