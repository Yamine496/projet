'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class apply extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  };
  apply.init({
    email: DataTypes.STRING,
    id_advertisements: DataTypes.INTEGER,
    id_client: DataTypes.INTEGER,
    message: DataTypes.STRING,
    message_back: DataTypes.STRING,
    name: DataTypes.STRING,
    phone: DataTypes.STRING,
    sujet: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'apply',
  });
  return apply;
};