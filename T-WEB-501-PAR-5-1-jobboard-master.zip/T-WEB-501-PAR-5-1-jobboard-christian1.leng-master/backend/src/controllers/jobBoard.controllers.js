const db = require("../models/jobBoard.models");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

module.exports.companies_get = (req, res) => {
  try {
    db.query(
      "SELECT DISTINCT name_companies, contact FROM companies ",
      (err, result) => {
        if (err) {
          res.send({ err });
        } else {
          res.send(result);
        }
      }
    );
  } catch (err) {
    throw new Error("Error [SELECT] companies", err);
  }
};
module.exports.advertisements_get = (req, res) => {
  try {
    db.query("SELECT * FROM advertisements", (err, result) => {
      if (err) {
        res.send({ err });
      } else {
        res.send(result);
      }
    });
  } catch (err) {
    throw new Error("Error [SELECT] advertisements", err);
  }
};

// SEND APPLY
module.exports.apply_post = async (req, res) => {
  const {
    sujet,
    name,
    email,
    phone,
    message,
    id_advertisements,
    id_client,
    id_recruteur,
  } = req.body;

  try {
    if (id_client) {
      let emailToLowerCase = await email.replace(/\s/g, "").toLowerCase();

      db.query(
        "INSERT INTO apply (sujet,name, email, phone,message,id_advertisements,id_client,id_recruteur,createdAt,updatedAt) VALUES (?,?,?,?,?,?,?,?,NOW(),NOW())",
        [
          sujet,
          name,
          emailToLowerCase,
          phone,
          message,
          id_advertisements,
          id_client,
          id_recruteur,
        ],
        (err, result) => {
          if (err) {
            res.send({ status: 1, err });
          } else {
            res.send({ status: 0, message: "Send !" });
          }
        }
      );
    } else {
      db.query(
        "INSERT INTO apply (sujet,name, email, phone,message,id_advertisements,id_client,createdAt,updatedAt) VALUES (?,?,?,?,?,?,?,NOW(),NOW())",
        [sujet, name, email, phone, message, id_advertisements, uuidv4()],
        (err, result) => {
          if (err) {
            res.status(404).send({ err });
          } else {
            res.status(200).send({ status: 0, message: "Send !" });
          }
        }
      );
    }
  } catch (err) {
    throw new Error("Error [INSERT] apply", err);
  }
};

// USER
module.exports.connexion_post = async (req, res) => {
  const { email, password } = req.body;

  try {
    if ((email, password)) {
      let emailToLowerCase = await email.replace(/\s/g, "").toLowerCase();

      db.query(
        "SELECT * FROM people WHERE email = ?",
        emailToLowerCase,
        (err, result) => {
          if (err) {
            res.send({ err });
          }
          if (result.length > 0) {
            bcrypt.compare(password, result[0].password, (error, response) => {
              if (response) {
                const id = result[0].id;
                const getRole = result[0].role;

                const token = jwt.sign({ id }, process.env.JWT_SECRET, {
                  expiresIn: process.env.DATE_EXPIRESIN,
                });
                const UserToken = { token };
                const UserRole = { getRole };
                const UserId = { id };
                const all = [...result, UserToken, UserRole, UserId];

                res.status(200).send(all);
              } else {
                res.send({
                  status: 1,
                  message: "Mauvais mot de passe ou email !",
                });
              }
            });
          } else {
            res.send({ status: 1, message: "Mauvais mot de passe ou email !" });
          }
        }
      );
    } else {
      res.send({ status: 1, message: "Veuillez mettre vos donnees." });
    }
  } catch (err) {
    throw new Error("Error [SELECT] connexion", err);
  }
};
module.exports.inscription_post = (req, res) => {
  const { name, password, email, role, phone } = req.body;

  if (name && password && email && role && phone) {
    db.query(
      "SELECT email FROM people WHERE email = ?",
      [email],
      (err, result) => {
        if (err) {
          res.send({ err });
        }
        if (result.length > 0) {
          res.send({ status: 1, message: "Adresse email deja utiliser." });
        } else {
          db.query(
            "SELECT name FROM people WHERE name = ?",
            [name],
            async (err, result) => {
              if (result.length > 0) {
                res.send({
                  message:
                    "Nom utilisateur deja utiliser. Veuillez en choisir une autre",
                });
              } else if (name.length < 3) {
                res.send({
                  message:
                    "Veuillez choisir un nom d'utilisateur avec plus de 4 caracteres.",
                });
              } else if (
                !email.match(/^[A-Za-z0-9.-_]+@[a-zA-Z0-9]+\.[a-zA-Z0-9]+$/)
              ) {
                res.send({
                  status: 1,
                  message: "Veuillez entrer une adresse email correct.",
                });
              } else {
                let hashedPassword = await bcrypt.hash(password, 10);
                let emailToLowerCase = await email
                  .replace(/\s/g, "")
                  .toLowerCase();

                db.query(
                  "INSERT INTO people (name, password, email, role, phone, createdAt, updatedAt) VALUES (?,?,?,?,?,NOW(),NOW())",
                  [name, hashedPassword, emailToLowerCase, role, phone],
                  (err, result) => {
                    if (err) {
                      res.status(404).send({ err });
                    } else {
                      res
                        .status(200)
                        .send({ status: 0, message: "Inscription reussi !" });
                    }
                  }
                );
              }
            }
          );
        }
      }
    );
  } else {
    res.status(404).send({
      message: "Entrer une adresse email et un mot de passe",
    });
  }
};
module.exports.profile_post = (req, res) => {
  const { id_recruteur } = req.body;

  try {
    db.query(
      "SELECT * FROM people WHERE id = ? ",
      id_recruteur,
      (err, result) => {
        if (err) {
          res.status(404).send({ err });
        } else {
          res.status(200).send(result);
        }
      }
    );
  } catch (err) {
    throw new Error("err [SELECT] people :", err);
  }
};
module.exports.update_profile_post = (req, res) => {
  const { email, name, phone, id } = req.body;
  try {
    db.query(
      "UPDATE people SET email = ?, name = ?, phone = ? WHERE id = ?",
      [email, name, phone, id],
      (err, result) => {
        if (err) {
          res.status(404).send({ err });
        } else {
          res.status(200).send({ message: "Update User !" });
        }
      }
    );
  } catch (err) {
    throw new Error("Error [UPDATE] user :", err);
  }
};

// CLIENT
module.exports.user_apply_post = (req, res) => {
  const { getUserID } = req.body;

  try {
    db.query(
      "SELECT * FROM apply WHERE id_client = ? ",
      getUserID,
      (err, result) => {
        if (err) {
          res.status(404).send({ err });
        } else {
          res.status(200).send(result);
        }
      }
    );
  } catch (err) {
    throw new Error("Error [SELECT] user apply :", err);
  }
};
module.exports.user_apply_get_ad_post = (req, res) => {
  const { id_advertisements } = req.body;

  try {
    db.query(
      "SELECT * FROM advertisements LEFT JOIN apply ON apply.id_advertisements = advertisements.id WHERE apply.id_advertisements IS NOT NULL",
      id_advertisements,
      (err, result) => {
        if (err) {
          res.status(404).send({ err });
        } else {
          res.status(200).send(result);
        }
      }
    );
  } catch (err) {
    throw new Error("Error [SELECT] user apply get add :", err);
  }
};

// RECRUTEUR
module.exports.create_ad_post = (req, res) => {
  const {
    contact,
    full_description,
    id_recruteur,
    name_companies,
    name_job,
    post_description,
    profil_description,
    salaire,
    small_description,
    ville,
    contrat,
  } = req.body;

  db.query(
    "INSERT INTO advertisements (contact,full_description,id_recruteur, name_companies, name_job,post_description,profil_description,salaire,small_description,ville,contrat,createdAt,updatedAt) VALUES (?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())",
    [
      contact,
      full_description,
      id_recruteur,
      name_companies,
      name_job,
      post_description,
      profil_description,
      salaire,
      small_description,
      ville,
      contrat,
    ],
    (err, result) => {
      if (err) {
        res.status(404).send({ err });
      } else {
        res.status(200).send({ message: "Annonce envoyé !" });
      }
    }
  );
  db.query(
    "SELECT name_companies FROM companies WHERE name_companies = ?",
    [name_companies],
    (err, result) => {
      if (err) {
        res.send({ err });
      }
      if (result.length > 0) {
        return;
      } else {
        db.query(
          "INSERT INTO companies (name_companies,contact,createdAt,updatedAt) VALUES (?,?,NOW(),NOW())",
          [name_companies, contact],
          (err, result) => {
            if (err) {
              res.status(404).send({ err });
            } else {
              res.status(200).send(result);
            }
          }
        );
      }
    }
  );
};
module.exports.all_ad_post = (req, res) => {
  const { getIDRecruiter } = req.body;

  try {
    db.query(
      "SELECT * FROM advertisements WHERE id_recruteur = ?",
      getIDRecruiter,
      (err, result) => {
        if (err) {
          res.send({ err });
        } else {
          res.send(result);
        }
      }
    );
  } catch (err) {
    throw new Error("Error get apply :", err);
  }
};
module.exports.delete_ad_post = (req, res) => {
  const { id, name_companies } = req.body;

  try {
    db.query("DELETE FROM advertisements WHERE id = ?", id, (err, result) => {
      if (err) {
        res.send({ err });
      } else {
        res.send(result);
      }
    });
    db.query(
      "DELETE FROM companies WHERE name_companies = ?",
      name_companies,
      (err, result) => {
        if (err) {
          res.send({ err });
        } else {
          res.send(result);
        }
      }
    );
  } catch (er) {
    throw new Error("err [DELETE] advertisements:", err);
  }
};
module.exports.update_ad_post = (req, res) => {
  const {
    name_job,
    name_companies,
    ville,
    contact,
    full_description,
    small_description,
    post_description,
    profil_description,
    salaire,
    id_recruteur,
    contrat,
    id,
  } = req.body;

  try {
    db.query(
      "UPDATE advertisements SET name_job = ?, ville = ?, contact = ?, name_companies = ?, full_description = ?, small_description = ?, post_description = ?, profil_description = ?, salaire = ?, id_recruteur = ?,contrat=? WHERE id = ?",
      [
        name_job,
        ville,
        contact,
        name_companies,
        full_description,
        small_description,
        post_description,
        profil_description,
        salaire,
        id_recruteur,
        contrat,
        id,
      ],
      (err, result) => {
        if (err) {
          res.status(404).send({ err });
        } else {
          res.status(200).send({ message: "Update advertisements !" });
        }
      }
    );
  } catch (er) {
    throw new Error("err [UPDATE] advertisements:", err);
  }
};
module.exports.get_user_apply = (req, res) => {
  const { getIDRecruiter } = req.body;

  try {
    db.query(
      "SELECT * FROM apply WHERE id_recruteur = ?",
      getIDRecruiter,
      (err, result) => {
        if (err) {
          res.status(404).send({ err });
        } else {
          res.status(200).send(result);
        }
      }
    );
  } catch (err) {
    throw new Error("Error [SELECT] apply :", err);
  }
};
module.exports.resend_apply_post = (req, res) => {
  const { message_back, id } = req.body;

  try {
    db.query(
      "UPDATE apply SET message_back = ? WHERE id = ?",
      [message_back, id],
      (err, result) => {
        if (err) {
          res.status(404).send({ err });
        } else {
          res.status(200).send({ message: "Resend back !" });
        }
      }
    );
  } catch (err) {
    throw new Error("Error [INSERT] resend apply", err);
  }
};

// ADMIN - USER
module.exports.display_all_users_get = (req, res) => {
  try {
    db.query("SELECT * FROM people", (err, result) => {
      if (err) {
        res.status(404).send({ err });
      } else {
        res.status(200).send(result);
      }
    });
  } catch (err) {
    throw new Error("Error [SELECT] get all users :", err);
  }
};
module.exports.delete_all_user_post = (req, res) => {
  const { id_user } = req.body;

  try {
    db.query("DELETE FROM people WHERE id = ?", id_user, (err, result) => {
      if (err) {
        res.status(404).send({ err });
      } else {
        res.status(200).send(result);
      }
    });
  } catch (err) {
    throw new Error("Error [DELETE] user :", err);
  }
};
module.exports.count_all_user_post = (req, res) => {
  const { id_user } = req.body;

  try {
    db.query(
      "SELECT message FROM apply WHERE id_client = ?",
      id_user,
      (err, result) => {
        if (err) {
          res.status(404).send({ err });
        } else {
          res.status(200).send(result);
        }
      }
    );
  } catch (err) {
    throw new Error("Error [SELECT COUNT] users :", err);
  }
};
module.exports.get_apply_user_post = (req, res) => {
  const { id_client } = req.body;
  try {
    db.query(
      "SELECT * FROM apply WHERE id_client = ?",
      [id_client],
      (err, result) => {
        if (err) {
          res.status(404).send({ err });
        } else {
          res.status(200).send(result);
        }
      }
    );
  } catch (err) {
    throw new Error("Error [SELECT] get apply user", err);
  }
};
module.exports.delete_apply_user_post = (req, res) => {
  const { id } = req.body;
  try {
    db.query("DELETE FROM apply WHERE id = ?", [id], (err, result) => {
      if (err) {
        res.status(404).send({ err });
      } else {
        res.status(200).send({ message: "Delete apply user !" });
      }
    });
  } catch (err) {
    throw new Error("Error [DELETE] apply user", err);
  }
};

// ADMIN - ADVERTISEMENTS
module.exports.display_all_ad_get = (req, res) => {
  try {
    db.query("SELECT * FROM advertisements", (err, result) => {
      if (err) {
        res.status(404).send({ err });
      } else {
        res.status(200).send(result);
      }
    });
  } catch (err) {
    throw new Error("Error [SELECT] all advertisements :", err);
  }
};
module.exports.delete_ad_post = (req, res) => {
  const { id_advertisement } = req.body;
  try {
    db.query(
      "DELETE FROM advertisements WHERE id = ?",
      [id_advertisement],
      (err, result) => {
        if (err) {
          res.status(404).send({ err });
        } else {
          res
            .status(200)
            .send({ status: 0, message: "Delete advertisement !" });
        }
      }
    );
    db.query(
      "DELETE FROM companies WHERE id = ?",
      [id_advertisement],
      (err, result) => {
        if (err) {
          res.status(404).send({ err });
        } else {
          res.status(200).send({ message: "Delete advertisement !" });
        }
      }
    );
  } catch (err) {
    throw new Error("Error [DELETE] advertisements :", err);
  }
};
module.exports.update_ad_post = (req, res) => {
  const {
    name_job,
    name_companies,
    contrat,
    contact,
    ville,
    salaire,
    full_description,
    small_description,
    post_description,
    profil_description,
    id_recruteur,
    id,
  } = req.body;

  try {
    db.query(
      "UPDATE advertisements SET name_job = ?, name_companies = ?, contrat = ?, contact = ?, ville = ?, salaire = ?, full_description = ?, small_description = ?, post_description = ?, profil_description = ?, id_recruteur = ? WHERE id= ?",
      [
        name_job,
        name_companies,
        contrat,
        contact,
        ville,
        salaire,
        full_description,
        small_description,
        post_description,
        profil_description,
        id_recruteur,
        id,
      ],
      (err, result) => {
        if (err) {
          res.status(404).send({ err });
        } else {
          res.status(200).send({ message: "Update advertisement !" });
        }
      }
    );
  } catch (err) {
    throw new Error("Error [UPDATE] advertisements :", err);
  }
};
