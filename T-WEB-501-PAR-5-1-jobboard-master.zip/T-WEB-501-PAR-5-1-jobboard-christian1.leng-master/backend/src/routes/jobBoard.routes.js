const { Router } = require("express");
const authControllers = require("../controllers/jobBoard.controllers");

const router = Router();

router.get("/companies", authControllers.companies_get);
router.get("/advertisements", authControllers.advertisements_get);

router.post("/send-apply", authControllers.apply_post);

// USER
router.post("/connexion", authControllers.connexion_post);
router.post("/inscription", authControllers.inscription_post);
router.post("/profile/:id", authControllers.profile_post);
router.post("/profile/update/:id", authControllers.update_profile_post);

// CLIENT
router.post("/user-apply/:id", authControllers.user_apply_post);
router.post(
  "/user-apply/get-advertisements/:id",
  authControllers.user_apply_get_ad_post
);

// RECRUTEUR
router.post("/create-advertisements", authControllers.create_ad_post);
router.post("/get-advertisements/:id", authControllers.all_ad_post);
router.post("/get-advertisements/delete/:id", authControllers.delete_ad_post);
router.post("/get-advertisements/update/:id", authControllers.update_ad_post);
router.post("/get-user-apply/:id", authControllers.get_user_apply);
router.post("/resend-apply/:id", authControllers.resend_apply_post);

// ADMIN - USER
router.get("/all-user", authControllers.display_all_users_get);
router.post("/all-user/delete/:id", authControllers.delete_all_user_post);
router.post("/all-user/count/:id", authControllers.count_all_user_post);
router.post("/get-apply-user/:id", authControllers.get_apply_user_post);
router.post("/delete-apply-user/:id", authControllers.delete_apply_user_post);

// ADMIN - ADVERTISEMENTS
router.post("/all-advertisements", authControllers.display_all_ad_get);
router.post("/delete-advertisement/:id", authControllers.delete_ad_post);
router.post("/update-advertisement/:id", authControllers.update_ad_post);

module.exports = router;
