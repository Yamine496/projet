"use strict";
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("apply", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      email: {
        type: Sequelize.STRING,
      },
      id_advertisements: {
        type: Sequelize.INTEGER,
      },
      id_client: {
        type: Sequelize.STRING,
      },
      id_recruteur: {
        type: Sequelize.INTEGER,
      },
      message: {
        type: Sequelize.STRING(1000),
      },
      message_back: {
        type: Sequelize.STRING(1000),
      },
      name: {
        type: Sequelize.STRING,
      },
      phone: {
        type: Sequelize.STRING,
      },
      sujet: {
        type: Sequelize.STRING(500),
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("applies");
  },
};
