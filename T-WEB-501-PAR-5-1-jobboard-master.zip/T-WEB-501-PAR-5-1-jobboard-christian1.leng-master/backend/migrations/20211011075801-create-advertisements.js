"use strict";
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("advertisements", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      contact: {
        type: Sequelize.STRING,
      },
      contrat: {
        type: Sequelize.STRING,
      },
      full_description: {
        type: Sequelize.STRING(1000),
      },
      id_recruteur: {
        type: Sequelize.INTEGER,
      },
      name_companies: {
        type: Sequelize.STRING,
      },
      name_job: {
        type: Sequelize.STRING,
      },
      post_description: {
        type: Sequelize.STRING(1000),
      },
      profil_description: {
        type: Sequelize.STRING(1000),
      },
      salaire: {
        type: Sequelize.STRING,
      },
      small_description: {
        type: Sequelize.STRING(1000),
      },
      ville: {
        type: Sequelize.STRING,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("advertisements");
  },
};
