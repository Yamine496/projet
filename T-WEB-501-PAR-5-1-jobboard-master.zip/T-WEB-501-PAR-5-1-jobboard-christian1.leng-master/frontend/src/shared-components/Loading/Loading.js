import React from "react";
import { CircularProgress } from "@material-ui/core";
import Center from "components/Center/Center";

const Loading = () => {
  return (
    <Center>
      <CircularProgress />
    </Center>
  );
};

export default Loading;
