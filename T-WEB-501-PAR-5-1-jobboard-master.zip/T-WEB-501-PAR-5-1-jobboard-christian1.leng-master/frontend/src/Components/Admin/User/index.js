import React, { useState, useEffect } from "react";
import { Box, Typography, makeStyles } from "@material-ui/core";
import AdminUserUpdateDelete from "./componentsUser/AdminUserUpdateDelete";
import axios from "axios";

const useStyles = makeStyles(() => ({
  root: {
    maxWidth: "1320px",
    margin: "auto",
    padding: "0 20px",
  },
  BoxFilter: {
    display: "flex",
    justifyContent: "space-between",
    flexWrap: "wrap",
  },
  BoxAdminUser: {
    marginTop: " 32px",
    "&:hover": {
      transform: "scale(1.012)",
      transitionDuration: "400ms",
    },
  },
  BoxCount: {
    display: "flex",
    flexWrap: "wrap",
  },
  d: {
    margin: "0 5px",
  },
}));

const AdminUser = ({ valuesAdmin }) => {
  const classes = useStyles();
  const [getValuesAdmin, setGetValuesAdmin] = useState([]);

  const fetchDataForUser = () => {
    return axios
      .get("/all-user")
      .then((res) => setGetValuesAdmin(res.data))
      .catch((err) => console.log("Error catch /all-user ", err));
  };

  useEffect(() => {
    fetchDataForUser();
  }, []);

  const getNbUser = getValuesAdmin.filter((v) => {
    return v.role !== "ADMIN";
  }).length;
  const getNbRecruteur = getValuesAdmin.filter((v) => {
    return v.role === "RECRUTEUR";
  }).length;
  const getNbClient = getValuesAdmin.filter((v) => {
    return v.role === "CLIENT";
  }).length;

  return (
    <Box className={classes.root}>
      <Box className={classes.BoxCount}>
        <Typography variant="h6" className={classes.d}>
          {getNbUser} {getNbUser > 1 ? "utilisateurs" : "utilisateurs"}
        </Typography>
        <Typography variant="h6" className={classes.d}>
          {getNbClient} {getNbClient > 1 ? "clients" : "client"}
        </Typography>
        <Typography variant="h6" className={classes.d}>
          {getNbRecruteur} {getNbRecruteur > 1 ? "recruteurs" : "recruteur"}
        </Typography>
      </Box>
      {getValuesAdmin
        .filter((v) => {
          return v.role === "CLIENT" || v.role === "RECRUTEUR";
        })
        .map((res) => (
          <Box key={res.id} className={classes.BoxAdminUser}>
            <AdminUserUpdateDelete res={res} />
          </Box>
        ))}
    </Box>
  );
};

export default AdminUser;
