import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  makeStyles,
  Button,
  Collapse,
} from "@material-ui/core";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import { getRandomColor } from "../../../../Utils/index";
import DeleteIcon from "@mui/icons-material/Delete";
import FormatAlignJustifyIcon from "@mui/icons-material/FormatAlignJustify";
import axios from "axios";
import moment from "moment";
import ShowMoreUser from "./ShowMoreUser";

const useStyles = makeStyles(() => ({
  root: {
    alignItems: "center",
    backgroundColor: "white",
    borderRadius: "7px",
    boxShadow: "5px 6px 25px 3px rgba(0, 0, 0, 0.3)",
    borderTopLeftRadius: "7px",
    borderBottomLeftRadius: "7px",
    borderLeft: "7px white solid",
    margin: "20px auto",
    padding: "5px 20px",
  },
  BoxUser: {
    margin: "10px",
    display: "flex",
    alignItems: "center",
    flexWrap: "wrap",
  },
  BoxIconUser: {
    paddingRight: "20px",
  },
  Name: {
    fontWeight: "bold",
  },
  Date: {
    marginTop: "10px",
  },
  BoxInfoUser: {
    margin: "10px",
  },
  BoxNb: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-end",
    flex: "3 1 0%",
  },
  BoxNbSecond: {
    boxSizing: "border-box",
    display: "grid",
    margin: "8px",
    gridTemplateColumns: "repeat(2, 1fr)",
    paddingRight: "32px",
  },
  BoxUpdateDelete: {
    display: "grid",
    padding: "10px 0",
  },
}));

const AdminUserUpdateDelete = ({ res }) => {
  const classes = useStyles();
  const [openCandidature, setOpenCandidature] = useState(false);
  const [valuesCount, setValuesCount] = useState([]);
  const [valuesMessage, setValuesMessage] = useState([]);
  const { id } = res;

  const fetchDataCountUser = () => {
    axios
      .post(`/all-user/count/${id}`, { id_user: id })
      .then((res) => setValuesCount(res.data))
      .catch((err) => console.log(err));
  };

  const fetchDataMessage = () => {
    axios
      .post(`/get-apply-user/${id}`, { id_client: id })
      .then((res) => setValuesMessage(res.data))
      .catch((err) => console.log(err));
  };

  const handleDeleteAdmin = (e) => {
    e.preventDefault();
    axios
      .post(`/all-user/delete/${id}`, {
        id_user: id,
      })
      .then(() => {
        window.location.reload();
      })
      .catch((err) => console.log(err));
  };

  useEffect(() => {
    fetchDataCountUser();
    fetchDataMessage();
  }, []);

  const countCandidaturesUser = valuesCount.length;
  const createdAtAdvertisements = moment(res.updatedAt).format("DD-MM-YYYY");

  return (
    <Box className={classes.root}>
      <Box className={classes.BoxUser}>
        <Box className={classes.BoxIconUser}>
          <AccountCircleIcon
            style={{ fontSize: "40px", color: getRandomColor() }}
          />
        </Box>
        <Box className={classes.BoxInfoUser}>
          <Typography className={classes.Name}>
            {res.name} - {res.role}
          </Typography>
          <Typography>{res.email}</Typography>
          <Typography>{res.phone}</Typography>
          <Typography className={classes.Date}>
            Date de création: {createdAtAdvertisements}
          </Typography>
        </Box>
        <Box className={classes.BoxNb}>
          <Box className={classes.BoxNbSecond}>
            {res.role === "CLIENT" && res.role !== "ADMIN" ? (
              <Box mx={2}>
                <Typography>
                  {countCandidaturesUser ? (
                    <>Nombre de candidature: {countCandidaturesUser}</>
                  ) : (
                    "Nombre de candidature: 0"
                  )}
                </Typography>
              </Box>
            ) : null}
          </Box>
        </Box>
        <Box className={classes.BoxUpdateDelete}>
          <Box pb={2}>
            <Button
              onClick={() => setOpenCandidature(!openCandidature)}
              variant="outlined"
              endIcon={<FormatAlignJustifyIcon className={classes.color} />}
            >
              Voir plus
            </Button>
          </Box>
          <Button
            color="secondary"
            onClick={handleDeleteAdmin}
            variant="outlined"
            endIcon={<DeleteIcon className={classes.color} />}
          >
            Supprimer
          </Button>
        </Box>
      </Box>
      <Collapse in={openCandidature}>
        {valuesMessage.map((v) => (
          <Box key={v.id}>
            <ShowMoreUser v={v} />
          </Box>
        ))}
      </Collapse>
    </Box>
  );
};

export default AdminUserUpdateDelete;
