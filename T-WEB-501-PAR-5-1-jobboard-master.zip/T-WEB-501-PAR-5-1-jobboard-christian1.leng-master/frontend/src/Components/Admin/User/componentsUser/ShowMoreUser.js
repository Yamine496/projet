import React from "react";
import {
  Box,
  Typography,
  makeStyles,
  Button,
  Divider,
} from "@material-ui/core";
import moment from "moment";
import axios from "axios";

const useStyles = makeStyles(() => ({
  SpanText: {
    fontWeight: "bolder",
  },
  ColorDivider: {
    backgroundColor: "rgb(76, 202, 64)",
    height: "2px",
    maxWidth: "500px",
  },
}));

const ShowMoreUser = ({ v }) => {
  const classes = useStyles();
  const updatedMessageUser = moment(v.updatedAt).format("DD-MM-YYYY");
  const { id } = v;

  const handleSubmit = (e) => {
    e.preventDefault();
    axios
      .post(`/delete-apply-user/${id}`, {
        id,
      })
      .then((res) => {
        if (res.data.message === "Delete apply user !") {
          window.location.reload();
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <>
      <Box my={2}>
        <Typography>
          <span className={classes.SpanText}>Sujet : </span>
          {v.sujet}
        </Typography>
        <Typography>
          <span className={classes.SpanText}>Message : </span>
          {v.message}
        </Typography>
        <Typography>
          <span className={classes.SpanText}>Envoyé le : </span>
          {updatedMessageUser}
        </Typography>
      </Box>
      <Box my={1}>
        <Button color="secondary" variant="outlined" onClick={handleSubmit}>
          Supprimer le message
        </Button>
      </Box>
      <Divider className={classes.ColorDivider} />
    </>
  );
};

export default ShowMoreUser;
