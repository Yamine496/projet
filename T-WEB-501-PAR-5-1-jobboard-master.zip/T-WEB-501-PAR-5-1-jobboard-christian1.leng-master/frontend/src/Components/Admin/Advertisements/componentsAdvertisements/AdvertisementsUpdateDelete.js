import React, { useState } from "react";
import {
  Box,
  Typography,
  Button,
  makeStyles,
  Collapse,
} from "@material-ui/core";
import axios from "axios";
import moment from "moment";
import UpdateAdvertisement from "./UpdateAdvertisement";

const useStyles = makeStyles((theme) => ({
  root: {
    alignItems: "center",
    backgroundColor: "white",
    borderRadius: "7px",
    boxShadow: "5px 6px 25px 3px rgba(0, 0, 0, 0.3)",
    borderTopLeftRadius: "7px",
    borderBottomLeftRadius: "7px",
    borderLeft: "7px white solid",
    margin: "20px auto",
    padding: "5px 20px",
  },
  BoxAdvertisement: {
    display: "flex",
    [theme.breakpoints.down("sm")]: {
      display: "inline-block",
    },
  },
  BoxSmallInfo: {
    margin: "10px 0",
  },
  BoxSmallInfoDesc: {
    margin: "22px 0",
  },
  SmallInfo: {
    margin: "10px 40px 10px 0",
  },
  SpanBolder: {
    fontWeight: "bolder",
  },
  BoxBtn: {
    margin: "10px 0",
  },
  BtnUpdate: {
    margin: "0 5px",
    [theme.breakpoints.down("sm")]: {
      margin: "5px 5px",
    },
    [theme.breakpoints.down("xs")]: {
      margin: "5px 0",
    },
  },
}));

const AdvertisementsUpdateDelete = ({ res }) => {
  const classes = useStyles();
  const [open, setOpen] = useState(false);
  const { id, name_companies } = res;
  const updatedAtAdvertisement = moment(res.updatedAt).format("DD-MM-YYYY");

  console.log(res);

  const handleDelete = () => {
    axios
      .post(`/delete-advertisement/${id}`, {
        id_advertisement: id,
        name_companies,
      })
      .then(() => window.location.reload())
      .catch((err) => console.log(err));
  };

  return (
    <Box className={classes.root}>
      <Typography variant="h4">{res.name_companies}</Typography>
      <Box className={classes.BoxAdvertisement}>
        <Box className={classes.BoxSmallInfo}>
          <Box className={classes.SmallInfo}>
            <Typography>
              <span className={classes.SpanBolder}>Job: </span>
              {res.name_job}
            </Typography>
            <Typography>
              <span className={classes.SpanBolder}>Contact: </span>
              {res.contact}
            </Typography>
            <Typography>
              <span className={classes.SpanBolder}>Contrat: </span>
              {res.contrat}
            </Typography>
            <Typography>
              <span className={classes.SpanBolder}>Mise en ligne: </span>
              {updatedAtAdvertisement}
            </Typography>
            <Typography>
              <span className={classes.SpanBolder}>Ville: </span>
              {res.ville}
            </Typography>
            <Typography>
              <span className={classes.SpanBolder}>Salaire: </span>
              {res.salaire}
            </Typography>
          </Box>
        </Box>
        <Box className={classes.BoxSmallInfoDesc}>
          <Typography>
            <span className={classes.SpanBolder}>Petite description: </span>
            {res.small_description}
          </Typography>
          <Box my={2}>
            <Typography>
              <span className={classes.SpanBolder}>Profil rechercher: </span>
              {res.profil_description}
            </Typography>
          </Box>
          <Typography>
            <span className={classes.SpanBolder}>Description du post: </span>
            {res.post_description}
          </Typography>
        </Box>
      </Box>
      <Box className={classes.BoxBtn}>
        <Button variant="outlined" color="secondary" onClick={handleDelete}>
          Supprimer
        </Button>
        <Button
          className={classes.BtnUpdate}
          variant="outlined"
          onClick={() => setOpen(!open)}
        >
          Mettre à jour
        </Button>
      </Box>
      <Collapse in={open}>
        <UpdateAdvertisement setOpen={setOpen} res={res} />
      </Collapse>
    </Box>
  );
};

export default AdvertisementsUpdateDelete;
