import React, { useState } from "react";
import { Box, TextField, makeStyles, Button } from "@material-ui/core";
import axios from "axios";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    [theme.breakpoints.down("xs")]: {
      flexWrap: "wrap",
    },
  },
  smalInfo: {
    display: "grid",
    padding: "0 20px 0 0",
  },
  test: {
    margin: "10px 0",
  },
}));

const UpdateAdvertisement = ({ setOpen, res }) => {
  const classes = useStyles();
  const [values, setValues] = useState({
    name_job: res ? res.name_job : "",
    name_companies: res ? res.name_companies : "",
    contrat: res ? res.contrat : "",
    contact: res ? res.contact : "",
    ville: res ? res.ville : "",
    salaire: res ? res.salaire : "",
    full_description: res ? res.full_description : "",
    small_description: res ? res.small_description : "",
    post_description: res ? res.post_description : "",
    profil_description: res ? res.profil_description : "",
    id_recruteur: "",
  });

  const { id: idAd, id_recruteur: idRecruteur } = res;

  const handleUpdateAdmin = (e) => {
    e.preventDefault();
    const {
      name_job,
      name_companies,
      contrat,
      contact,
      ville,
      salaire,
      full_description,
      small_description,
      post_description,
      profil_description,
    } = values;

    axios
      .post(`/update-advertisement/${idAd}`, {
        name_job,
        name_companies,
        contrat,
        contact,
        ville,
        salaire,
        full_description,
        small_description,
        post_description,
        profil_description,
        id_recruteur: idRecruteur,
        id: idAd,
      })
      .then((res) => {
        if (res.data.message === "Update advertisement !") {
          setOpen(false);
          window.location.reload();
        }
      })
      .catch((err) => console.log(err));
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value,
    });
  };

  return (
    <Box>
      <Box className={classes.root}>
        <Box className={classes.smalInfo}>
          <TextField
            className={classes.TextFieldMargin}
            variant="outlined"
            name="name_job"
            label="Job"
            type="job"
            value={values.name_job}
            onChange={handleChange}
          />
          <TextField
            className={classes.test}
            variant="outlined"
            name="name_companies"
            label="Companie"
            type="companie"
            value={values.name_companies}
            onChange={handleChange}
          />
          <TextField
            className={classes.TextFieldMargin}
            variant="outlined"
            name="contrat"
            label="Contrat"
            type="name"
            value={values.contrat}
            onChange={handleChange}
          />
          <TextField
            className={classes.test}
            variant="outlined"
            name="contact"
            label="contact"
            type="contact"
            value={values.contact}
            onChange={handleChange}
          />
          <TextField
            variant="outlined"
            name="ville"
            label="Ville"
            type="name"
            value={values.ville}
            onChange={handleChange}
          />
          <TextField
            className={classes.test}
            variant="outlined"
            name="salaire"
            label="salaire"
            type="name"
            value={values.salaire}
            onChange={handleChange}
          />
        </Box>
        <Box className={classes.BigInfo}>
          <TextField
            variant="outlined"
            multiline
            fullWidth
            rows={6}
            name="full_description"
            type="full_description"
            label="Description complète"
            value={values.full_description}
            onChange={handleChange}
          />
          <TextField
            className={classes.test}
            variant="outlined"
            multiline
            fullWidth
            rows={6}
            name="small_description"
            type="small_description"
            label="Petite description"
            value={values.small_description}
            onChange={handleChange}
          />
          <TextField
            variant="outlined"
            multiline
            fullWidth
            rows={6}
            name="post_description"
            type="post_description"
            label="Description du post"
            value={values.post_description}
            onChange={handleChange}
          />
          <TextField
            className={classes.test}
            variant="outlined"
            multiline
            fullWidth
            rows={6}
            name="profil_description"
            type="profil_description"
            label="Profil rechercher"
            value={values.profil_description}
            onChange={handleChange}
          />
        </Box>
      </Box>
      <Button variant="outlined" onClick={handleUpdateAdmin}>
        Modifier
      </Button>
    </Box>
  );
};

export default UpdateAdvertisement;
