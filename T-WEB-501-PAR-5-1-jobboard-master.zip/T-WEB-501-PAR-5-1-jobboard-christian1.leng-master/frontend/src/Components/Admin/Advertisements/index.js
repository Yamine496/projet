import React, { useState, useEffect } from "react";
import { Box, makeStyles } from "@material-ui/core";
import axios from "axios";
import AdvertisementsUpdateDelete from "./componentsAdvertisements/AdvertisementsUpdateDelete";

const useStyles = makeStyles(() => ({
  root: {
    maxWidth: "1320px",
    margin: "auto",
    padding: "0 20px",
  },
  BoxAdminAdvertisements: {
    marginTop: " 32px",
    "&:hover": {
      transform: "scale(1.012)",
      transitionDuration: "400ms",
    },
  },
}));

const AdminAdvertisements = () => {
  const classes = useStyles();
  const [valuesAdvertisements, setValuesAdvertisements] = useState([]);

  const fetchDataAdvertisements = () => {
    axios
      .post("all-advertisements")
      .then((res) => {
        setValuesAdvertisements(res.data);
      })
      .catch((err) => console.log(err));
  };

  useEffect(() => {
    fetchDataAdvertisements();
  }, []);

  return (
    <Box className={classes.root}>
      {valuesAdvertisements.map((res) => (
        <Box key={res.id} className={classes.BoxAdminAdvertisements}>
          <AdvertisementsUpdateDelete res={res} />
        </Box>
      ))}
    </Box>
  );
};

export default AdminAdvertisements;
