import React from "react";
import { Box, Typography, makeStyles } from "@material-ui/core";
import moment from "moment";
import CheckIcon from "@mui/icons-material/Check";

const useStyles = makeStyles((theme) => ({
  root: {
    margin: "22px 100px",
    borderRadius: "7px",
    boxShadow: "5px 6px 25px 3px rgba(0, 0, 0, 0.3)",
    display: "grid",
    gridTemplateColumns: "auto 1fr auto",
    gridTemplateRows: "1fr auto",
    [theme.breakpoints.down("sm")]: {
      gridTemplateColumns: "1fr",
      margin: "22px 10px",
    },
  },
  BoxCompanie: {
    margin: "0 20px",
    display: "flex",
    alignItems: "center",
  },
  BoxCandidature: {
    margin: "15px 0",
    alignItems: "center",
    [theme.breakpoints.down("sm")]: {
      margin: "5px 18px",
    },
  },
  BoxDate: {
    textAlign: "center",
    margin: "25px 5px",
    [theme.breakpoints.down("sm")]: {
      margin: "5px 17px",
      display: "flex",
    },
  },
  color: {
    color: "rgb(76, 202, 64)",
  },
  send: {
    margin: "0 5px",
  },
  spanFont: {
    fontWeight: "bolder",
  },
  MessageBack: {
    marginTop: "5px",
  },
}));

const Apply = ({ item }) => {
  const classes = useStyles();
  const updatedAtCandidature = moment(item.updatedAt).format("DD-MM-YYYY");

  return (
    <Box className={classes.root}>
      <Box className={classes.BoxCompanie}>
        <Typography variant="h4">{item.name_companies}</Typography>
      </Box>
      <Box className={classes.BoxCandidature}>
        <Typography>
          <span className={classes.spanFont}>Sujet : </span>
          {item.sujet}
        </Typography>
        <Typography>
          <span className={classes.spanFont}>Message : </span>
          {item.message}
        </Typography>
        <Typography>
          <span className={classes.spanFont}>E-mail : </span>
          {item.email}
        </Typography>
        {item.message_back ? (
          <Typography className={classes.MessageBack}>
            <span className={classes.spanFont}>Réponse : </span>
            {item.message_back}
          </Typography>
        ) : null}
      </Box>
      <Box className={classes.BoxDate}>
        <Typography>
          <CheckIcon className={classes.color} />
        </Typography>
        <Typography className={classes.send}>Candidature envoyée le</Typography>
        <Typography> {updatedAtCandidature}</Typography>
      </Box>
    </Box>
  );
};

export default Apply;
