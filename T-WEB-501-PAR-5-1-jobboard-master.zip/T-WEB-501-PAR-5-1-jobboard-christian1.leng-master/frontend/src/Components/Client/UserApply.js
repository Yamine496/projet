import React, { useState, useEffect } from "react";
import { Box, Typography } from "@material-ui/core";
import axios from "axios";
import Apply from "./Apply/Apply";

const UserApply = ({ valuesApplys, getUserID }) => {
  const [valuesApply, setValuesApply] = useState([]);

  const getAdID = valuesApplys.id_advertisements;

  const fetchGetAd = () => {
    return axios
      .post(`/user-apply/get-advertisements/${getUserID}`, {
        id_advertisements: getAdID,
      })
      .then((res) => setValuesApply(res.data))
      .catch((err) => console.log("Error fetchDataApply", err));
  };

  useEffect(() => {
    fetchGetAd();
  });

  const countCandidature = valuesApply.filter((i) => {
    return parseInt(i.id_client) === getUserID;
  }).length;

  return (
    <Box>
      <Box mx={13}>
        <Typography>{countCandidature} candidatures</Typography>
      </Box>
      {valuesApply
        .filter((i) => {
          return parseInt(i.id_client) === getUserID;
        })
        .map((item) => (
          <Box key={item.id}>
            <Apply item={item} />
          </Box>
        ))}
    </Box>
  );
};

export default UserApply;
