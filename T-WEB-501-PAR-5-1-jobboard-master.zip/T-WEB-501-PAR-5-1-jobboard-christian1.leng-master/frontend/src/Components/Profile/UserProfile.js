import React, { useState } from "react";
import {
  Box,
  Typography,
  Button,
  Collapse,
  TextField,
} from "@material-ui/core";
import axios from "axios";
import moment from "moment";

const UserProfile = ({ valueUser }) => {
  const [open, setOpen] = useState(false);
  const [values, setValues] = useState({
    email: "",
    name: "",
    phone: "",
  });

  const handleUpdate = (e) => {
    e.preventDefault();
    const { email, name, phone } = values;
    const getIdRecruteur = JSON.parse(localStorage.getItem("id")).id;

    axios
      .post(`/profile/update/${getIdRecruteur}`, {
        email,
        name,
        phone,
        id: getIdRecruteur,
      })
      .then((res) => {
        if (res.data.message === "Update User !") {
          setValues({
            email: "",
            name: "",
            phone: "",
          });
          setOpen(false);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value,
    });
  };

  const updatedAtUser = moment(valueUser.updatedAt).format("DD-MM-YYYY");

  return (
    <Box textAlign="center">
      <Typography>
        <span style={{ fontWeight: "bolder" }}>E-mail : </span>
        {valueUser.email}
      </Typography>
      <Typography>
        <span style={{ fontWeight: "bolder" }}>Name : </span>
        {valueUser.name}
      </Typography>
      <Typography>
        <span style={{ fontWeight: "bolder" }}>Phone : </span>
        {valueUser.phone}
      </Typography>
      <Typography>
        <span style={{ fontWeight: "bolder" }}>Créer le : </span>
        {updatedAtUser}
      </Typography>
      <Button onClick={() => setOpen(!open)}>Modifier</Button>
      <Collapse in={open}>
        <Box>
          <Typography variant="h5">E-mail :</Typography>
          <TextField
            id="email"
            name="email"
            label="email"
            placeholder="Ex: exemple@test.com"
            value={values.email}
            onChange={handleChange}
          />
        </Box>
        <Box>
          <Typography variant="h5">Name :</Typography>
          <TextField
            id="name"
            name="name"
            label="name"
            placeholder="Ex: Christian"
            value={values.name}
            onChange={handleChange}
          />
        </Box>
        <Box>
          <Typography variant="h5">Phone :</Typography>
          <TextField
            id="phone"
            name="phone"
            label="phone"
            placeholder="Ex: Christian"
            value={values.phone}
            onChange={handleChange}
          />
        </Box>
        <Button onClick={handleUpdate}>Mettre à jour</Button>
      </Collapse>
    </Box>
  );
};

export default UserProfile;
