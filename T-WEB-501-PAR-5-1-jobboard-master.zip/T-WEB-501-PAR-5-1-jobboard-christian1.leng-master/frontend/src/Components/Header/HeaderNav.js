import React, { useState } from "react";
import { makeStyles, MenuItem, Box, MenuList } from "@material-ui/core";
import { useHistory } from "react-router-dom";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "210px",
    display: "flex",
  },
  typographyLink: {
    "&:hover": {
      color: theme.palette.primary.main,
    },
    margin: theme.spacing(2, 1, 2, 2),
  },
}));

const HeaderNav = () => {
  const classes = useStyles();
  const history = useHistory();
  const userMenuRef = React.useRef(null);
  const [userMenu, setUserMenu] = useState(false);

  const handleCloseUserMenu = (event) => {
    if (userMenuRef.current && userMenuRef.current.contains(event.target)) {
      return;
    }
    setUserMenu(false);
  };

  function handleUMListKeyDown(event) {
    if (event.key === "Tab") {
      event.preventDefault();
      setUserMenu(false);
    }
  }

  const handleMenuItemClick = (item) => (event) => {
    handleCloseUserMenu(event);
    switch (item) {
      case "advertisements":
        history.push(`/advertisements`);
        break;
      case "companies":
        history.push(`/companies`);
        break;
      default:
        break;
    }
  };

  return (
    <Box className={classes.root}>
      <MenuList
        autoFocusItem={userMenu}
        id="menu-list-grow"
        onKeyDown={handleUMListKeyDown}
      >
        <MenuItem onClick={handleMenuItemClick("advertisements")}>
          Trouver une offre
        </MenuItem>
        <MenuItem onClick={handleMenuItemClick("companies")}>
          Découvrir les entreprises
        </MenuItem>
      </MenuList>
    </Box>
  );
};

export default HeaderNav;
