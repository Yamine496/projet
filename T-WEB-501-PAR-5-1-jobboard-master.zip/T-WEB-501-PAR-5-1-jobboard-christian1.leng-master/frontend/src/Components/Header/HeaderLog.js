import React, { useState, useRef } from "react";
import {
  makeStyles,
  MenuItem,
  MenuList,
  Divider,
  ClickAwayListener,
  Box,
  IconButton,
} from "@material-ui/core";
import { useHistory } from "react-router-dom";
import ChevronRightIcon from "@material-ui/icons/ChevronRight";
import InsertInvitationIcon from "@material-ui/icons/InsertInvitation";
import PersonIcon from "@material-ui/icons/Person";

const useStyles = makeStyles((theme) => ({
  userMenuIcons: {
    marginRight: theme.spacing(2),
    color: theme.palette.primary.main,
  },
}));

const HeaderLog = ({ setOpen }) => {
  const classes = useStyles();
  const history = useHistory();
  const [userMenu, setUserMenu] = useState(false);
  const userMenuRef = useRef(null);
  const getUserRole = JSON.parse(localStorage.getItem("role")) || "";
  const getRole = getUserRole.getRole || "";

  const handleDrawerClose = () => {
    setOpen(false);
  };

  const handleCloseUserMenu = (event) => {
    if (userMenuRef.current && userMenuRef.current.contains(event.target)) {
      return;
    }
    setUserMenu(false);
  };

  function handleUMListKeyDown(event) {
    if (event.key === "Tab") {
      event.preventDefault();
      setUserMenu(false);
    }
  }

  const handleMenuItemClick = (item) => (event) => {
    handleCloseUserMenu(event);
    switch (item) {
      case "profile":
        history.push(`/profile`);
        break;
      case "AdvertisementsClient":
        history.push(`/advertisements-client`);
        break;
      case "CreateAdvertisement":
        history.push(`/create-advertisement`);
        break;
      case "AllAdvertisements":
        history.push(`/all-advertisement`);
        break;
      case "AdminUser":
        history.push(`/admin-user`);
        break;
      case "AdminAd":
        history.push(`/admin-ad`);
        break;
      case "connexion":
        history.push("/connexion");
        break;
      case "inscription":
        history.push("/inscription");
        break;
      default:
        break;
    }
  };

  return (
    <>
      <div>
        <IconButton onClick={handleDrawerClose}>
          <ChevronRightIcon />
        </IconButton>
      </div>
      <Divider />
      {getRole ? (
        <ClickAwayListener onClickAway={handleCloseUserMenu}>
          <MenuList
            autoFocusItem={userMenu}
            id="menu-list-grow"
            onKeyDown={handleUMListKeyDown}
          >
            {getRole === "CLIENT" ? (
              <>
                <MenuItem onClick={handleMenuItemClick("AdvertisementsClient")}>
                  <InsertInvitationIcon
                    className={classes.userMenuIcons}
                    fontSize="small"
                  />
                  Mes candidature(s)
                </MenuItem>
                <MenuItem onClick={handleMenuItemClick("profile")}>
                  <PersonIcon
                    className={classes.userMenuIcons}
                    fontSize="small"
                  />
                  Profil
                </MenuItem>
              </>
            ) : null}
            {getRole === "RECRUTEUR" ? (
              <>
                <MenuItem onClick={handleMenuItemClick("CreateAdvertisement")}>
                  <InsertInvitationIcon
                    className={classes.userMenuIcons}
                    fontSize="small"
                  />
                  Creer une annonce
                </MenuItem>
                <MenuItem onClick={handleMenuItemClick("AllAdvertisements")}>
                  <PersonIcon
                    className={classes.userMenuIcons}
                    fontSize="small"
                  />
                  Mes annonce(s)
                </MenuItem>
              </>
            ) : null}
            {getRole === "ADMIN" ? (
              <>
                <MenuItem onClick={handleMenuItemClick("AdminUser")}>
                  <InsertInvitationIcon
                    className={classes.userMenuIcons}
                    fontSize="small"
                  />
                  Admin utilisateurs
                </MenuItem>
                <MenuItem onClick={handleMenuItemClick("AdminAd")}>
                  <InsertInvitationIcon
                    className={classes.userMenuIcons}
                    fontSize="small"
                  />
                  Admin Annonces
                </MenuItem>
              </>
            ) : null}
            <Divider />
          </MenuList>
        </ClickAwayListener>
      ) : (
        <Box m={1}>
          {!getRole && (
            <MenuList
              autoFocusItem={userMenu}
              id="menu-list-grow"
              onKeyDown={handleUMListKeyDown}
            >
              <MenuItem onClick={handleMenuItemClick("connexion")}>
                <PersonIcon
                  className={classes.userMenuIcons}
                  fontSize="small"
                />
                Connexion
              </MenuItem>
              <MenuItem onClick={handleMenuItemClick("inscription")}>
                <PersonIcon
                  className={classes.userMenuIcons}
                  fontSize="small"
                />
                Inscription
              </MenuItem>
              <Divider />
            </MenuList>
          )}
        </Box>
      )}
    </>
  );
};

export default HeaderLog;
