import React, { useState } from "react";
import {
  Button,
  Collapse,
  Box,
  Typography,
  TextField,
  makeStyles,
} from "@material-ui/core";
import axios from "axios";
import SendIcon from "@mui/icons-material/Send";
import VisibilityIcon from "@mui/icons-material/Visibility";
import moment from "moment";

const { v4: uuidv4 } = require("uuid");
const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
    marginBottom: "50px",
  },
  LogoBox: {
    margin: "0 24px 0 0",
  },
  InfoBox: {
    display: "flex",
    flexDirection: "column",
  },
  InfoTop: {
    display: "flex",
    alignItems: "center",
    marginBottom: "14px",
  },
  Company: {
    fontWeight: "bolder",
    color: "rgb(76,202,64)",
    marginRight: "15px",
    cursor: "pointer",
  },
  InfoMain: {
    fontWeight: "bolder",
    fontSize: "18px",
  },
  Information: {
    fontSize: "16px",
    marginTop: "20px",
  },
  LearnMore: {
    padding: "10px 10px 0 0",
    display: "flex",
  },
  BoxLearnMore: {
    display: "flex",
    flexWrap: "wrap",
    justifyContent: "center",
  },
  color: {
    color: "rgb(76, 202, 64)",
  },
  learnMoreDescription: {
    marginTop: "15px",
  },
  InputApply: {
    margin: "10px 10px",
  },
  InfoBottom: {
    marginTop: "12px",
    display: "flex",
    color: "hsl(180, 8%, 52%)",
    fontSize: "15px",
    whiteSpace: "nowrap",
    [theme.breakpoints.down("xs")]: {
      flexWrap: "wrap",
    },
  },
}));

const RandomId = uuidv4();

const UserID = JSON.parse(localStorage.getItem("id")) || "";
const getUserID = UserID.id || "";

const UserRole = JSON.parse(localStorage.getItem("role")) || "";
const getUserRole = UserRole.getRole || "";

const UserInfo = JSON.parse(localStorage.getItem("user")) || "";
const { email: emailUser, name: nameUser, phone: phoneUser } = UserInfo;

const AllAdvertisements = ({ item }) => {
  const classes = useStyles();
  const [open, setOpen] = useState(false);
  const [values, setValues] = useState({
    sujet: "",
    name: "",
    email: "",
    phone: "",
    message: "",
  });
  const [informationMessage, setInformationMessage] = useState("");
  const [learnMore, setLearnMore] = useState(false);

  const { id, id_recruteur } = item;

  const handleClickOpen = () => {
    setLearnMore((prev) => !prev);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const { sujet, name, email, phone, message } = values;
    if (message || sujet) {
      axios
        .post("/send-apply", {
          sujet,
          name: getUserRole === "CLIENT" ? nameUser : name,
          email: getUserRole === "CLIENT" ? emailUser : email,
          phone: getUserRole === "CLIENT" ? phoneUser : phone,
          message,
          id_advertisements: id,
          id_client: getUserRole ? getUserID : RandomId,
          id_recruteur: id_recruteur,
        })
        .then((response) => {
          if (response.data.message) {
            console.log("response =>", response);
            setInformationMessage(response.data.message);
            if (response.data.message === "Send !") {
              setValues({
                sujet: "",
                name: "",
                email: "",
                phone: "",
                message: "",
              });
              setOpen(false);
            }
          } else {
            setInformationMessage(response.data[0]);
          }
        });
    } else {
      console.log("Error");
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value,
    });
  };

  const createdAtAdvertisements = moment(item.updatedAt).format("DD-MM-YYYY");

  return (
    <Box px={5} py={1}>
      <Box className="advertisement">
        <Box className={classes.root}>
          <Box className={classes.LogoBox}>
            <Typography variant="h4">{item.name_companies}</Typography>
          </Box>
          <Box>
            <Box className={classes.InfoBox}>
              <Box className={classes.InfoTop}>
                <Box className={classes.Company}>
                  {item.name_job} - {item.contrat}
                </Box>
              </Box>
              <Box className={classes.InfoMain}>
                <Box>
                  {learnMore ? (
                    <Box>
                      <Box>
                        <Typography
                          variant="h5"
                          className={classes.learnMoreDescription}
                        >
                          Description complète
                        </Typography>
                        <Typography>{item.full_description}</Typography>
                      </Box>
                      <Box>
                        <Typography
                          variant="h5"
                          className={classes.learnMoreDescription}
                        >
                          Description du poste
                        </Typography>
                        <Typography>{item.post_description}</Typography>
                      </Box>
                      <Box>
                        <Typography
                          variant="h5"
                          className={classes.learnMoreDescription}
                        >
                          Profil rechercher
                        </Typography>
                        <Typography>{item.profil_description}</Typography>
                      </Box>
                    </Box>
                  ) : (
                    <>
                      <Typography
                        variant="h5"
                        className={classes.learnMoreDescription}
                      >
                        Petite description
                      </Typography>
                      <Typography>
                        {item.small_description.slice(0, 250)}...
                      </Typography>
                    </>
                  )}
                </Box>
              </Box>
              <Box className={classes.Information}>{item.contact}</Box>
              <Box className={classes.InfoBottom}>
                <span>{item.ville}</span>
                <span>{item.contact}</span>
                <span>{createdAtAdvertisements}</span>
              </Box>
              <Typography>{item.salaire}</Typography>
            </Box>
          </Box>
          <Box className={classes.BoxLearnMore}>
            <Box className={classes.LearnMore}>
              <Button
                variant="contained"
                onClick={handleClickOpen}
                endIcon={<VisibilityIcon className={classes.color} />}
              >
                Voir plus
              </Button>
            </Box>
            {getUserRole !== "RECRUTEUR" && getUserRole !== "ADMIN" ? (
              <Box className={classes.LearnMore}>
                <Button
                  onClick={() => setOpen(!open)}
                  variant="contained"
                  endIcon={<SendIcon className={classes.color} />}
                >
                  Candidature
                </Button>
              </Box>
            ) : null}
          </Box>
        </Box>
        <Collapse in={open} aria-labelledby="details-collapse" unmountOnExit>
          <Box textAlign="center">
            <Typography variant="h5">Candidature</Typography>
            <Box>
              {getUserRole ? (
                <>
                  <TextField
                    className={classes.InputApply}
                    name="sujet"
                    label="sujet"
                    variant="outlined"
                    value={values.sujet}
                    onChange={handleChange}
                  />
                  <TextField
                    className={classes.InputApply}
                    name="message"
                    label="Message"
                    variant="outlined"
                    multiline
                    rows={6}
                    value={values.message}
                    onChange={handleChange}
                  />
                </>
              ) : (
                <>
                  <Box>
                    <TextField
                      className={classes.InputApply}
                      name="sujet"
                      label="sujet"
                      variant="outlined"
                      value={values.sujet}
                      onChange={handleChange}
                    />
                    <TextField
                      className={classes.InputApply}
                      name="name"
                      label="name"
                      variant="outlined"
                      value={values.name}
                      onChange={handleChange}
                    />
                    <TextField
                      className={classes.InputApply}
                      name="email"
                      label="email"
                      variant="outlined"
                      value={values.email
                        .trim()
                        .replace(/\s/g, "")
                        .toLowerCase()}
                      onChange={handleChange}
                    />
                    <TextField
                      className={classes.InputApply}
                      name="phone"
                      label="phone"
                      variant="outlined"
                      value={values.phone.replace(/\s/g, "")}
                      onChange={handleChange}
                    />
                  </Box>
                  <TextField
                    className={classes.InputApply}
                    name="message"
                    label="Message"
                    variant="outlined"
                    multiline
                    rows={6}
                    value={values.message}
                    onChange={handleChange}
                  />
                </>
              )}
            </Box>
            <Button variant="contained" onClick={handleSubmit}>
              Envoyer
            </Button>
            <Typography>{informationMessage}</Typography>
          </Box>
        </Collapse>
      </Box>
    </Box>
  );
};

export default AllAdvertisements;
