import React from "react";
import { Box, Typography, makeStyles } from "@material-ui/core";
import { Link } from "react-router-dom";

const useStyles = makeStyles(() => ({
  root: {
    display: "flex",
    flexirection: "column",
    alignItems: "center",
    padding: "30px",
    margin: "0 20px 20px 20px",
    borderRadius: "8px",
    width: "170px",
    textAlign: "center",
    transition: ".3s",
    "&:hover": {
      transform: "scale(1.2)",
      boxShadow: "5px 6px 25px 3px rgba(0, 0, 0, 0.3)",
      cursor: "pointer",
    },
  },
  TypographyContact: {},
}));

const AllCompanie = ({ item }) => {
  const classes = useStyles();

  return (
    <Box className={classes.root}>
      <Link className="linkNav" to="/advertisements">
        <Typography variant="h4">{item.name_companies}</Typography>
        <Typography variant="h6" className={classes.TypographyContact}>
          {item.contact}
        </Typography>
      </Link>
    </Box>
  );
};

export default AllCompanie;
