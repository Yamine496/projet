import React, { useState } from "react";
import {
  Box,
  Typography,
  makeStyles,
  Button,
  TextField,
  Collapse,
} from "@material-ui/core";
import moment from "moment";
import axios from "axios";

const useStyles = makeStyles((theme) => ({
  root: {
    margin: "22px 100px",
    borderRadius: "7px",
    boxShadow: "5px 6px 25px 3px rgba(0, 0, 0, 0.3)",
    [theme.breakpoints.down("sm")]: {
      margin: "22px 20px",
    },
  },
  BoxMessage: {
    display: "flex",
    [theme.breakpoints.down("sm")]: {
      display: "inline-block",
      margin: "22px 30px 0 30px",
    },
  },
  BoxDate: {
    display: "flex",
    alignItems: "center",
    flexWrap: "wrap",
    justifyContent: "center",
    margin: "0 29px 5px 0",
    [theme.breakpoints.down("sm")]: {
      margin: "0 29px 5px 29px",
    },
  },
  spanText: {
    fontWeight: "bolder",
  },
  BoxCollapse: {
    margin: "10px",
    paddingBottom: "10px",
  },
  BtnCollapse: {
    marginTop: "5px",
    color: "rgb(76, 202, 64)",
  },
}));

const GetApply = ({ valueApply }) => {
  const classes = useStyles();
  const valueApplyUpdatedAt = moment(valueApply.updatedAt).format("DD-MM-YYYY");
  const [open, setOpen] = useState(false);
  const [values, setValues] = useState({
    message: valueApply ? valueApply.message_back : "",
  });
  const { id } = valueApply;

  const handleSubmit = (e) => {
    e.preventDefault();
    const { message } = values;

    axios
      .post(`/resend-apply/${id}`, { message_back: message, id })
      .then((res) => {
        if (res.data.message === "Resend back !") {
          setValues({ message: "" });
          setOpen(false);
        }
      });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value,
    });
  };

  return (
    <Box className={classes.root}>
      <Box className={classes.BoxMessage}>
        <Box py={4} px={4} alignItems="center" textAlign="left">
          <Typography>
            <span className={classes.spanText}>Sujet : </span>
            {valueApply.sujet}
          </Typography>
          <Typography>
            <span className={classes.spanText}>Message : </span>
            {valueApply.message}
          </Typography>
          <Typography>
            <span className={classes.spanText}>Name : </span>
            {valueApply.name}
          </Typography>
          <Typography>
            <span className={classes.spanText}>E-mail : </span>
            {valueApply.email}
          </Typography>
          <Typography>
            <span className={classes.spanText}>Téléphone : </span>
            {valueApply.phone}
          </Typography>
        </Box>
        <Box className={classes.BoxDate}>
          <Typography>Candidature envoyée le {valueApplyUpdatedAt}</Typography>
          <Box mx={2}>
            <Button variant="outlined" onClick={() => setOpen(!open)}>
              Répondre
            </Button>
          </Box>
        </Box>
      </Box>
      <Collapse in={open} className={classes.BoxCollapse}>
        <TextField
          className={classes.InputApply}
          name="message"
          label="Message..."
          variant="outlined"
          fullWidth
          multiline
          rows={6}
          value={values.message}
          onChange={handleChange}
        />
        <Button
          className={classes.BtnCollapse}
          fullWidth
          variant="outlined"
          onClick={handleSubmit}
        >
          {valueApply.message_back ? "Modifier" : "Envoyer"}
        </Button>
      </Collapse>
    </Box>
  );
};

export default GetApply;
