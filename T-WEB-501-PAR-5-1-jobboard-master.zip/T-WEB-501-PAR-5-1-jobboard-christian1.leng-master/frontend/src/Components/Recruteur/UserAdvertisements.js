import React, { useState } from "react";
import {
  Box,
  Typography,
  Button,
  makeStyles,
  Grid,
  Collapse,
} from "@material-ui/core";
import axios from "axios";
import UpdateAdvertisements from "./UpdateAdvertisements";
import moment from "moment";

const useStyles = makeStyles((theme) => ({
  Over: {
    overflow: "scrollX",
  },
  LearnMore: {
    display: "flex",
    paddingRight: "4px",
  },
  BoxCompanie: {
    [theme.breakpoints.down("xs")]: {
      display: "block",
    },
  },
  SpanText: {
    fontWeight: "bolder",
  },
}));

const UserAdvertisements = ({ valueAdvertisements }) => {
  const classes = useStyles();
  const {
    contact,
    full_description,
    name_job,
    salaire,
    small_description,
    ville,
    post_description,
    profil_description,
    name_companies,
    updatedAt,
  } = valueAdvertisements;
  const [open, setOpen] = useState(false);

  const { id } = valueAdvertisements;

  const handleDelete = (e) => {
    e.preventDefault();
    axios
      .post(`/get-advertisements/delete/${id}`, { id })
      .then((res) => {
        return res.data;
      })
      .catch((err) => console.log(err));
    window.location.reload();
  };

  const getUpdatedAt = moment(updatedAt).format("DD-MM-YYYY");

  return (
    <Box>
      <Box
        py={4}
        px={4}
        display="flex"
        alignItems="center"
        justifyContent="space-between"
        textAlign="left"
      >
        <Grid container spacing={2} className={classes.BoxCompanie}>
          <Grid item xs={4}>
            <Box>
              <Box my={2}>
                <Typography>
                  <span className={classes.SpanText}>Nom du job :</span>
                </Typography>
                <Typography>{name_job}</Typography>
              </Box>
              <Box my={2}>
                <Typography>
                  <span className={classes.SpanText}>
                    Nom de l'entreprise :
                  </span>
                </Typography>
                <Typography>{name_companies}</Typography>
              </Box>
              <Box my={2}>
                <Typography>
                  <span className={classes.SpanText}>Ville :</span>
                </Typography>
                <Typography>{ville}</Typography>
              </Box>
              <Box my={2}>
                <Typography>
                  <span className={classes.SpanText}>Contact :</span>
                </Typography>
                <Typography>{contact}</Typography>
              </Box>
              <Box my={2}>
                <Typography>
                  <span className={classes.SpanText}>Mise en ligne :</span>
                </Typography>
                <Typography>{getUpdatedAt}</Typography>
              </Box>
            </Box>
          </Grid>
          <Grid item xs={8}>
            <Box>
              <Box my={2}>
                <Typography>
                  <span className={classes.SpanText}>
                    Description complète :
                  </span>
                </Typography>
                <Typography className={classes.Over}>
                  {full_description.slice(0, 200)}...
                </Typography>
              </Box>
              <Box my={2}>
                <Typography>
                  <span className={classes.SpanText}>Petite description :</span>
                </Typography>
                <Typography>{small_description.slice(0, 100)}...</Typography>
              </Box>
              <Box my={2}>
                <Typography>
                  <span className={classes.SpanText}>Salaire :</span>
                </Typography>
                <Typography>{salaire ? salaire : null}</Typography>
              </Box>
              <Box my={2}>
                <Typography>
                  <span className={classes.SpanText}>Type de contrat :</span>
                </Typography>
                <Typography>Alternance</Typography>
              </Box>
              <Box my={2}>
                <Typography>
                  <span className={classes.SpanText}>
                    Descriptif du poste :
                  </span>
                </Typography>
                <Typography>{post_description.slice(0, 100)}...</Typography>
              </Box>
              <Box my={2}>
                <Typography>
                  <span className={classes.SpanText}>Profil recherché :</span>
                </Typography>
                <Typography>{profil_description.slice(0, 100)}...</Typography>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Box>
      <Box m={2} display="flex" justifyContent="center">
        <Box className={classes.LearnMore}>
          <Button
            variant="outlined"
            className="linkNav"
            onClick={() => setOpen(!open)}
          >
            Mettre à jour
          </Button>
        </Box>
        <Box className={classes.LearnMore}>
          <Button variant="outlined" className="linkNav" onClick={handleDelete}>
            Supprimer
          </Button>
        </Box>
      </Box>
      <Box>
        <Collapse in={open}>
          <UpdateAdvertisements
            valueAdvertisements={valueAdvertisements}
            id={id}
            setOpen={setOpen}
          />
        </Collapse>
      </Box>
    </Box>
  );
};

export default UserAdvertisements;
