import React, { useState } from "react";
import axios from "axios";
import {
  Box,
  TextField,
  InputLabel,
  Button,
  makeStyles,
  Typography,
} from "@material-ui/core";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    [theme.breakpoints.down("xs")]: {
      flexWrap: "wrap",
    },
  },
}));

const UpdateAdvertisements = ({ id, setOpen, valueAdvertisements }) => {
  const classes = useStyles();
  const [values, setValues] = useState({
    name_job: valueAdvertisements ? valueAdvertisements.name_job : "",
    name_companies: valueAdvertisements
      ? valueAdvertisements.name_companies
      : "",
    ville: valueAdvertisements ? valueAdvertisements.ville : "",
    contact: valueAdvertisements ? valueAdvertisements.contact : "",
    full_description: valueAdvertisements
      ? valueAdvertisements.full_description
      : "",
    small_description: valueAdvertisements
      ? valueAdvertisements.small_description
      : "",
    post_description: valueAdvertisements
      ? valueAdvertisements.post_description
      : "",
    profil_description: valueAdvertisements
      ? valueAdvertisements.profil_description
      : "",
    contrat: valueAdvertisements ? valueAdvertisements.contrat : "",
    salaire: valueAdvertisements ? valueAdvertisements.salaire : "",
  });
  const [offreMessage, setOffreMessage] = useState();

  const handleSubmit = (e) => {
    e.preventDefault();
    const {
      name_job,
      ville,
      contact,
      full_description,
      name_companies,
      post_description,
      profil_description,
      small_description,
      contrat,
      salaire,
    } = values;
    const getIdRecruteur = JSON.parse(localStorage.getItem("id")).id;

    axios
      .post(`/get-advertisements/update/${id}`, {
        name_job,
        name_companies,
        ville,
        contact,
        full_description,
        small_description,
        post_description,
        profil_description,
        salaire,
        id_recruteur: getIdRecruteur,
        contrat,
        id,
      })
      .then((res) => {
        if (res.data.message) {
          setOffreMessage(res.data.message);
          if (res.data.message === "Update advertisements !") {
            setValues({
              name_job: "",
              name_companies: "",
              ville: "",
              contact: "",
              full_description: "",
              small_description: "",
              post_description: "",
              profil_description: "",
              contrat: "",
              salaire: "",
            });
            setOpen(false);
            window.location.reload();
          }
        }
      })
      .catch((err) => {
        console.log("[err] create offre :", err);
      });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value,
    });
  };

  return (
    <Box>
      <Box className={classes.root}>
        <Box>
          <Box m={2}>
            <TextField
              margin="normal"
              required
              variant="outlined"
              label="Nom du job"
              name="name_job"
              type="name_job"
              value={values.name_job}
              onChange={handleChange}
            />
          </Box>
          <Box m={2}>
            <TextField
              margin="normal"
              required
              label="Companie"
              variant="outlined"
              name="name_companies"
              type="name_companies"
              value={values.name_companies}
              onChange={handleChange}
            />
          </Box>
          <Box m={2}>
            <TextField
              margin="normal"
              required
              label="Ville"
              variant="outlined"
              name="ville"
              type="ville"
              value={values.ville}
              onChange={handleChange}
            />
          </Box>
          <Box m={2}>
            <TextField
              margin="normal"
              required
              label="Contact"
              variant="outlined"
              name="contact"
              type="contact"
              value={values.contact}
              onChange={handleChange}
            />
          </Box>
          <Box m={2}>
            <InputLabel>Contrat</InputLabel>
            <TextField
              margin="normal"
              required
              label="Contrat"
              variant="outlined"
              name="contrat"
              type="contrat"
              value={values.contrat}
              onChange={handleChange}
            />
          </Box>
          <Box m={2}>
            <TextField
              margin="normal"
              required
              label="salaire"
              variant="outlined"
              name="salaire"
              type="salaire"
              value={values.salaire}
              onChange={handleChange}
            />
          </Box>
        </Box>
        <Box>
          <TextField
            margin="normal"
            required
            label="Description complète"
            variant="outlined"
            multiline
            rows={6}
            name="full_description"
            type="full_description"
            value={values.full_description}
            onChange={handleChange}
          />
          <TextField
            margin="normal"
            required
            label="Petite description"
            variant="outlined"
            multiline
            rows={6}
            name="small_description"
            type="small_description"
            value={values.small_description}
            onChange={handleChange}
          />
          <TextField
            margin="normal"
            required
            label="Description du post"
            variant="outlined"
            multiline
            rows={6}
            name="post_description"
            type="post_description"
            value={values.post_description}
            onChange={handleChange}
          />
          <TextField
            margin="normal"
            required
            label="Description du profil"
            variant="outlined"
            multiline
            rows={6}
            name="profil_description"
            type="profil_description"
            value={values.profil_description}
            onChange={handleChange}
          />
        </Box>
      </Box>
      <Box textAlign="center" my={2}>
        <Typography>{offreMessage}</Typography>
        <Button onClick={handleSubmit}>Envoyer</Button>
      </Box>
    </Box>
  );
};

export default UpdateAdvertisements;
