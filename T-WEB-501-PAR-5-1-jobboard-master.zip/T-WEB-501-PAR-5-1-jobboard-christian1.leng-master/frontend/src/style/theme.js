import { createTheme, responsiveFontSizes } from "@mui/material/styles";

let jobboardTheme = createTheme({
  palette: {
    primary: { main: "#4cca40", light: "#fce4ec" },
    secondary: { main: "#EFEFEF" },
  },
  typography: {
    h1: {
      fontFamily: ["Lato", "Helvetica Neue", "sans-serif"],
    },
    h2: {
      fontFamily: ["Lato", "Helvetica Neue", "sans-serif"],
    },
    h3: {
      fontFamily: ["Lato", "Helvetica Neue", "sans-serif"],
    },
    h4: {
      fontFamily: ["Lato", "Helvetica Neue", "sans-serif"],
    },
    h5: {
      fontFamily: ["Lato", "Helvetica Neue", "sans-serif"],
    },
    h6: {
      fontFamily: ["Lato", "Helvetica Neue", "sans-serif"],
    },
    button: {
      fontFamily: ["Lato", "Helvetica Neue", "sans-serif"],
    },
    allVariants: {
      fontFamily: ["Source Sans Pro", "Helvetica Neue", "sans-serif"],
    },
  },
});
jobboardTheme = responsiveFontSizes(jobboardTheme);

export { jobboardTheme };
