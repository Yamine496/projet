import React from "react";
import { Route, Redirect } from "react-router-dom";

const UserToken = JSON.parse(localStorage.getItem("role")) || "";
const getUserToken = UserToken.token || "";

const JobBoardRoute = ({ component: Component, ...rest }) => {
  return (
    <Route
      {...rest}
      render={(componentProps) => (
        <>
          {getUserToken !== null ? (
            <Component {...componentProps} />
          ) : (
            <Redirect
              to={{
                pathname: "/connexion",
              }}
            />
          )}
        </>
      )}
    />
  );
};

export default JobBoardRoute;
