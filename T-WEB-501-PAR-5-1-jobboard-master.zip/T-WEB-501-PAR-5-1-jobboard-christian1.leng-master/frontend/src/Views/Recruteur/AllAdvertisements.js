import React, { useState, useEffect } from "react";
import axios from "axios";
import { Box, Typography, makeStyles, Divider } from "@material-ui/core";
import GetApply from "../../Components/Recruteur/GetApply";
import UserAdvertisements from "../../Components/Recruteur/UserAdvertisements";

const useStyles = makeStyles((theme) => ({
  root: {
    margin: "22px 100px",
    borderRadius: "7px",
    boxShadow: "5px 6px 25px 3px rgba(0, 0, 0, 0.3)",
    [theme.breakpoints.down("sm")]: {
      margin: "22px 20px",
    },
  },
  divider: {
    margin: "22px 100px",
    height: "3px",
  },
}));

const UserID = JSON.parse(localStorage.getItem("id")) || "";
const getIDRecruiter = UserID.id || "";

const AllAdvertisements = () => {
  const classes = useStyles();
  const [values, setValues] = useState([]);
  const [valuesApply, setValuesApply] = useState([]);

  const fetchDataAdvertisements = () => {
    return axios
      .post(`/get-advertisements/${getIDRecruiter}`, {
        getIDRecruiter,
      })
      .then((res) => {
        setValues(res.data);
      })
      .catch((err) => console.log("Error fetchDataAdvertisements ", err));
  };

  const fetchDataApply = () => {
    return axios
      .post(`/get-user-apply/${getIDRecruiter}`, { getIDRecruiter })
      .then((res) => {
        setValuesApply(res.data);
      })
      .catch((err) => console.log("Error fetchDataApply", err));
  };

  useEffect(() => {
    fetchDataAdvertisements();
    fetchDataApply();
  }, []);

  return (
    <Box py={4}>
      <Box textAlign="center">
        <Typography variant="h4">Mes offre(s)</Typography>
      </Box>
      {valuesApply.map((valueApply) => (
        <Box key={valueApply.id}>
          <GetApply valueApply={valueApply} />
        </Box>
      ))}
      <Divider className={classes.divider} />
      {values.map((valueAdvertisements) => (
        <Box className={classes.root} key={valueAdvertisements.id}>
          <UserAdvertisements valueAdvertisements={valueAdvertisements} />
        </Box>
      ))}
    </Box>
  );
};

export default AllAdvertisements;
