import React, { useState } from "react";
import axios from "axios";
import {
  Box,
  TextField,
  InputLabel,
  Button,
  Typography,
} from "@material-ui/core";

const CreateAdvertisement = () => {
  const [values, setValues] = useState({
    name_job: "",
    name_companies: "",
    ville: "",
    contact: "",
    full_description: "",
    small_description: "",
    salaire: "",
    profil_description: "",
    post_description: "",
    contrat: "",
  });
  const [offreMessage, setOffreMessage] = useState();

  const handleSubmit = (e) => {
    e.preventDefault();
    const {
      name_job,
      name_companies,
      ville,
      contact,
      full_description,
      small_description,
      salaire,
      profil_description,
      post_description,
      contrat,
    } = values;
    const getIdRecruteur = JSON.parse(localStorage.getItem("id")).id;

    axios
      .post("/create-advertisements", {
        name_job,
        name_companies,
        ville,
        contact,
        full_description,
        small_description,
        salaire,
        id_recruteur: getIdRecruteur,
        profil_description,
        post_description,
        contrat,
      })
      .then((res) => {
        if (res.data.message) {
          setOffreMessage(res.data.message);
          if (res.data.message === "Annonce envoyé !") {
            setValues({
              name_job: "",
              name_companies: "",
              ville: "",
              contact: "",
              full_description: "",
              small_description: "",
              salaire: "",
              profil_description: "",
              post_description: "",
              contrat: "",
            });
          }
        }
      })
      .catch((err) => {
        console.log("[err] create offre :", err);
      });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value,
    });
  };

  return (
    <Box textAlign="center">
      <Box>
        <Box py={4} textAlign="center">
          <Typography variant="h4">Ajouter une offre</Typography>
        </Box>
        <Box textAlign="center">
          <Box display="flex" flexWrap="wrap" justifyContent="space-evenly">
            <Box m={2}>
              <InputLabel>Nom du job*</InputLabel>
              <TextField
                variant="outlined"
                margin="normal"
                required
                name="name_job"
                type="name_job"
                value={values.name_job}
                onChange={handleChange}
              />
            </Box>
            <Box m={2}>
              <InputLabel>Companie*</InputLabel>
              <TextField
                variant="outlined"
                margin="normal"
                required
                name="name_companies"
                type="name_companies"
                value={values.name_companies}
                onChange={handleChange}
              />
            </Box>
            <Box m={2}>
              <InputLabel>Ville*</InputLabel>
              <TextField
                variant="outlined"
                margin="normal"
                required
                name="ville"
                type="ville"
                value={values.ville}
                onChange={handleChange}
              />
            </Box>
            <Box m={2}>
              <InputLabel>Contact*</InputLabel>
              <TextField
                variant="outlined"
                margin="normal"
                required
                name="contact"
                type="contact"
                value={values.contact}
                onChange={handleChange}
              />
            </Box>
          </Box>
          <Box display="flex" flexWrap="wrap" justifyContent="space-evenly">
            <Box m={2}>
              <InputLabel>Description complète*</InputLabel>
              <TextField
                variant="outlined"
                multiline
                rows={6}
                margin="normal"
                required
                name="full_description"
                type="full_description"
                value={values.full_description}
                onChange={handleChange}
              />
            </Box>
            <Box m={2}>
              <InputLabel>Petite description*</InputLabel>
              <TextField
                variant="outlined"
                multiline
                rows={6}
                margin="normal"
                required
                name="small_description"
                type="small_description"
                value={values.small_description}
                onChange={handleChange}
              />
            </Box>
            <Box m={2}>
              <InputLabel>Description du poste*</InputLabel>
              <TextField
                variant="outlined"
                multiline
                rows={6}
                margin="normal"
                required
                name="post_description"
                type="post_description"
                value={values.post_description}
                onChange={handleChange}
              />
            </Box>
            <Box m={2}>
              <InputLabel>Profil rechercher*</InputLabel>
              <TextField
                variant="outlined"
                multiline
                rows={6}
                margin="normal"
                required
                name="profil_description"
                type="profil_description"
                value={values.profil_description}
                onChange={handleChange}
              />
            </Box>
          </Box>
          <Box display="flex" flexWrap="wrap" justifyContent="space-evenly">
            <Box m={2}>
              <InputLabel>Contrat*</InputLabel>
              <TextField
                variant="outlined"
                margin="normal"
                required
                name="contrat"
                type="contrat"
                value={values.contrat}
                onChange={handleChange}
              />
            </Box>
            <Box m={2}>
              <InputLabel>Salaire*</InputLabel>
              <TextField
                variant="outlined"
                margin="normal"
                required
                name="salaire"
                type="salaire"
                value={values.salaire}
                onChange={handleChange}
              />
            </Box>
          </Box>
        </Box>
        <Typography>{offreMessage}</Typography>
        <Button onClick={handleSubmit}>Envoyer</Button>
        <Typography>* champs obligatoires</Typography>
      </Box>
    </Box>
  );
};

export default CreateAdvertisement;
