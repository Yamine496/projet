import React, { useEffect, useState } from "react";
import { Box } from "@material-ui/core";
import AdminUser from "../../Components/Admin/User/index";
import axios from "axios";

const AdminUsers = () => {
  const [valuesAdmin, setValuesAdmin] = useState([]);

  const fetchDataForUser = () => {
    return axios
      .get("/all-user")
      .then((res) => setValuesAdmin(res.data))
      .catch((err) => console.log("Error catch /all-user ", err));
  };

  useEffect(() => {
    fetchDataForUser();
  }, []);

  return (
    <Box py={5}>
      <AdminUser valuesAdmin={valuesAdmin} />
    </Box>
  );
};

export default AdminUsers;
