import React from "react";
import { Box } from "@material-ui/core";
import AdminAd from "../../Components/Admin/Advertisements/index";

const AdminAdvertisements = () => {
  return (
    <Box>
      <AdminAd />
    </Box>
  );
};

export default AdminAdvertisements;
