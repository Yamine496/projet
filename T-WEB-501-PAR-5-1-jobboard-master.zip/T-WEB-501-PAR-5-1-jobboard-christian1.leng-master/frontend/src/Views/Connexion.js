import React, { useState } from "react";
import {
  Box,
  Typography,
  TextField,
  Button,
  makeStyles,
} from "@material-ui/core";
import axios from "axios";

const useStyles = makeStyles(() => ({
  color: {
    color: "rgb(76, 202, 64)",
  },
}));

function Connexion() {
  const classes = useStyles();
  const [values, setValues] = useState({
    pseudo: "",
    email: "",
    password: "",
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const { pseudo, email, password } = values;
    axios
      .post("/connexion", {
        pseudo: pseudo,
        email: email,
        password: password,
      })
      .then((response) => {
        if (response.data.message) {
          console.log(response.data.message);
        } else {
          window.location.href = "/";
        }
        if ((email, password)) {
          if (response.data) {
            localStorage.setItem("user", JSON.stringify(response.data[0]));
            localStorage.setItem("token", JSON.stringify(response.data[1]));
            localStorage.setItem("role", JSON.stringify(response.data[2]));
            localStorage.setItem("id", JSON.stringify(response.data[3]));
          } else {
            console.log("erreur localstorage");
          }
        }
      });
    setValues({ email: "", password: "" });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value,
    });
  };

  return (
    <Box>
      <Box py={4} textAlign="center">
        <Typography variant="h4">Connexion</Typography>
      </Box>
      <Box textAlign="center">
        <Box my={2}>
          <TextField
            variant="outlined"
            id="email"
            name="email"
            label="email"
            placeholder="Ex: example@gmail.com"
            value={values.email.trim().replace(/\s/g, "").toLowerCase()}
            onChange={handleChange}
          />
        </Box>
        <Box my={2}>
          <TextField
            variant="outlined"
            id="password"
            name="password"
            label="Password"
            type="password"
            placeholder="Mot de passe"
            value={values.password}
            onChange={handleChange}
          />
        </Box>
        <Button
          variant="outlined"
          className={classes.color}
          onClick={handleSubmit}
        >
          Connexion
        </Button>
      </Box>
    </Box>
  );
}

export default Connexion;
