import React, { useState, useEffect } from "react";
import axios from "axios";
import { Box, Typography } from "@material-ui/core";
import UserProfile from "../Components/Profile/UserProfile";

const UserID = JSON.parse(localStorage.getItem("id")) || "";
const getUserID = UserID.id || "";

const Profile = () => {
  const [dataUser, setDataUser] = useState([]);

  const fetchDataUser = () => {
    return axios
      .post(`/profile/${getUserID}`, { id_recruteur: getUserID })
      .then((res) => {
        setDataUser(res.data);
      })
      .catch((err) => console.log("err => ", err));
  };

  useEffect(() => {
    fetchDataUser();
  }, []);

  return (
    <div>
      <Box py={4} textAlign="center">
        <Typography variant="h4">Profil</Typography>
      </Box>
      {dataUser.map((valueUser) => (
        <Box key={valueUser.id}>
          <UserProfile valueUser={valueUser} />
        </Box>
      ))}
    </div>
  );
};

export default Profile;
