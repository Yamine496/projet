import React, { useState, useEffect } from "react";
import { Box, Typography, makeStyles } from "@material-ui/core";
import axios from "axios";
import AllCompanie from "../Components/Companie/AllCompanie";

const useStyles = makeStyles(() => ({
  root: {
    display: "flex",
    flexWrap: "wrap",
    maxWidth: "1200px",
    margin: "0 auto",
    justifyContent: "center",
    paddingTop: "50px",
  },
}));

const Companies = () => {
  const classes = useStyles();
  const [getData, setGetData] = useState([]);

  const fetchDataCompanies = () => {
    return axios
      .get("/companies")
      .then((v) => {
        setGetData(v.data);
      })
      .catch((err) => console.log(err));
  };

  useEffect(() => {
    fetchDataCompanies();
  }, []);

  return (
    <Box py={4}>
      <Box textAlign="center">
        <Typography variant="h4">Entreprise(s)</Typography>
      </Box>
      <Box className={classes.root}>
        {getData.map((item) => (
          <Box key={item.id}>
            <AllCompanie item={item} />
          </Box>
        ))}
      </Box>
    </Box>
  );
};

export default Companies;
