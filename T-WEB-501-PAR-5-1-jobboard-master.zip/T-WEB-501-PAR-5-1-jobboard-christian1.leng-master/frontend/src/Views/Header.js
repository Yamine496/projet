import React, { useState } from "react";
import {
  useMediaQuery,
  useTheme,
  MenuItem,
  Drawer,
  IconButton,
  Divider,
  ClickAwayListener,
  MenuList,
  Box,
  Typography,
  List,
  makeStyles,
  ListItem,
} from "@material-ui/core";
import { Link } from "react-router-dom";
import MenuIcon from "@material-ui/icons/Menu";
import PowerSettingsNewIcon from "@material-ui/icons/PowerSettingsNew";
import HeaderNav from "../Components/Header/HeaderNav";
import HeaderLog from "../Components/Header/HeaderLog";

const useStyles = makeStyles((theme) => ({
  userMenuIcons: {
    marginRight: theme.spacing(1),
    color: theme.palette.primary.main,
  },
  MainHeader: {
    backgroundColor: "white",
    height: "70px",
    boxShadow:
      "0px 2px 4px -1px rgb(0 0 0 / 20%), 0px 4px 5px 0px rgb(0 0 0 / 14%), 0px 1px 10px 0px rgb(0 0 0 / 12%)",
  },
}));

const Header = () => {
  const classes = useStyles();
  const theme = useTheme();
  const wipeOffDrawer = useMediaQuery(theme.breakpoints.down("sm"));
  const [userMenu, setUserMenu] = useState(false);
  const [openDrawer, setOpenDrawer] = useState(false);
  const userMenuRef = React.useRef(null);
  const matches = useMediaQuery("(min-width:1200px)");
  const getUserRole = JSON.parse(localStorage.getItem("role")) || "";
  const getRole = getUserRole.getRole || "";

  const handleDrawerOnClose = () => {
    setOpenDrawer(!openDrawer);
  };

  const handleCloseUserMenu = (event) => {
    if (userMenuRef.current && userMenuRef.current.contains(event.target)) {
      return;
    }
    setUserMenu(false);
  };

  function handleUMListKeyDown(event) {
    if (event.key === "Tab") {
      event.preventDefault();
      setUserMenu(false);
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("role");
    localStorage.removeItem("id");
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "/";
  };

  return (
    <header className={classes.MainHeader}>
      <Link style={{ textDecoration: "none", color: "black" }} to="/">
        <Typography variant="h4">JobBoard</Typography>
      </Link>
      {wipeOffDrawer ? (
        <>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="end"
            onClick={handleDrawerOnClose}
          >
            <MenuIcon />
          </IconButton>
          <Drawer
            anchor="right"
            open={openDrawer}
            onClose={handleDrawerOnClose}
          >
            <HeaderLog setOpen={setOpenDrawer} />
            <HeaderNav />
            {getRole ? (
              <ClickAwayListener onClickAway={handleCloseUserMenu}>
                <MenuList
                  autoFocusItem={userMenu}
                  id="menu-list-grow"
                  onKeyDown={handleUMListKeyDown}
                >
                  <Divider />
                  <MenuItem onClick={handleLogout}>
                    <PowerSettingsNewIcon
                      fontSize="small"
                      className={classes.userMenuIcons}
                    />
                    Se déconnecter
                  </MenuItem>
                </MenuList>
              </ClickAwayListener>
            ) : null}
          </Drawer>
        </>
      ) : (
        <nav>
          <List className="ulNav">
            <Link className="linkNav" to="/advertisements">
              <ListItem className="liNav">
                {matches ? "Trouver une offre" : "Offre(s)"}
              </ListItem>
            </Link>
            <Link className="linkNav" to="/companies">
              <ListItem className="liNav">
                {matches ? "Découvrir les entreprises" : "Entreprise(s)"}
              </ListItem>
            </Link>
            {!getRole ? (
              <>
                <Link className="linkNav" to="/inscription">
                  <ListItem className="liNav">Inscription</ListItem>
                </Link>
                <Link className="linkNav" to="/connexion">
                  <ListItem className="liNav">Connexion</ListItem>
                </Link>
              </>
            ) : (
              <Box display="flex" alignContent="center">
                {getRole === "CLIENT" ? (
                  <Link to="/advertisements-client" className="linkNav">
                    <ListItem className="liNav">Mes candidature(s)</ListItem>
                  </Link>
                ) : null}
                {getRole === "RECRUTEUR" ? (
                  <>
                    <Link to="/create-advertisement" className="linkNav">
                      <ListItem className="liNav">Ajouter une offre</ListItem>
                    </Link>
                    <Link to="/all-advertisement" className="linkNav">
                      <ListItem className="liNav">Mes offre(s)</ListItem>
                    </Link>
                  </>
                ) : null}
                {getRole === "ADMIN" ? (
                  <>
                    <Link to="/admin-user" className="linkNav">
                      <ListItem className="liNav">Admin utilisateurs</ListItem>
                    </Link>
                    <Link to="/admin-ad" className="linkNav">
                      <ListItem className="liNav">Admin offres</ListItem>
                    </Link>
                  </>
                ) : null}
                {getRole === "ADMIN" ? null : (
                  <Link to="/profile" className="linkNav">
                    <ListItem className="liNav">Profil</ListItem>
                  </Link>
                )}
                <Link to="/" className="linkNav" onClick={handleLogout}>
                  <ListItem className="liNav">
                    <PowerSettingsNewIcon
                      fontSize="small"
                      className={classes.userMenuIcons}
                    />
                    Se déconnecter
                  </ListItem>
                </Link>
              </Box>
            )}
          </List>
        </nav>
      )}
    </header>
  );
};

export default Header;
