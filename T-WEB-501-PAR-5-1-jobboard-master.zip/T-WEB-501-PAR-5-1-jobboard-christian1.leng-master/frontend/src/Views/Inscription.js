import React, { useState } from "react";
import {
  Button,
  Box,
  Typography,
  TextField,
  Select,
  MenuItem,
  makeStyles,
} from "@material-ui/core";
import axios from "axios";

const useStyles = makeStyles(() => ({
  color: {
    color: "rgb(76, 202, 64)",
  },
}));

const Inscription = () => {
  const classes = useStyles();
  const [values, setValues] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    role: "",
  });
  const [inscriptionMessage, setInscriptionMessage] = useState();

  const handleSubmit = (e) => {
    e.preventDefault();
    const { name, email, password, phone, role } = values;
    axios
      .post("/inscription", {
        name,
        email,
        password,
        phone,
        role,
      })
      .then((response) => {
        if (response.data.message) {
          setInscriptionMessage(response.data.message);
          if (response.data.message === "Inscription reussi !") {
            setValues({
              name: "",
              email: "",
              password: "",
              phone: "",
              role: "",
            });
          }
        } else {
          setInscriptionMessage(response.data[0].email);
        }
      });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value,
    });
  };

  return (
    <Box>
      <Box py={4} textAlign="center">
        <Typography variant="h4">Inscription</Typography>
      </Box>
      <Box display="flex" justifyContent="center">
        <Box>
          <Box my={1}>
            <TextField
              variant="outlined"
              id="name"
              name="name"
              label="Nom"
              type="name"
              value={values.name}
              onChange={handleChange}
            />
          </Box>
          <Box my={1}>
            <TextField
              variant="outlined"
              id="email"
              name="email"
              label="E-mail"
              type="email"
              value={values.email.trim().replace(/\s/g, "").toLowerCase()}
              onChange={handleChange}
            />
          </Box>
          <Box my={1}>
            <TextField
              variant="outlined"
              id="phone"
              name="phone"
              label="Téléphone"
              type="phone"
              value={values.phone.replace(/\s/g, "")}
              onChange={handleChange}
            />
          </Box>
          <Box my={1}>
            <TextField
              variant="outlined"
              id="password"
              name="password"
              label="Mot de passes"
              type="password"
              value={values.password}
              onChange={handleChange}
            />
          </Box>
          <Box my={1}>
            <Select
              label="Rôle"
              variant="outlined"
              name="role"
              defaultValue="RECRUTEUR"
              value={values.role}
              onChange={handleChange}
            >
              <MenuItem value="RECRUTEUR">Recruteur</MenuItem>
              <MenuItem value="CLIENT">Client</MenuItem>
            </Select>
          </Box>
          <Button
            className={classes.color}
            variant="outlined"
            onClick={handleSubmit}
          >
            Envoyer
          </Button>
          <Typography>{inscriptionMessage}</Typography>
        </Box>
      </Box>
    </Box>
  );
};

export default Inscription;
