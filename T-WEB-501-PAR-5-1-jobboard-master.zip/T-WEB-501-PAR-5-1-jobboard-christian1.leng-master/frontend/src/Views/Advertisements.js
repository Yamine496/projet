import React, { useState, useEffect } from "react";
import axios from "axios";
import AllAdvertisements from "../Components/AllAdvertisements";
import { Box, Typography, makeStyles } from "@material-ui/core";

const useStyles = makeStyles((theme) => ({
  root: {
    alignItems: "center",
    backgroundColor: "white",
    margin: "22px 110px",
    padding: "31px 0",
    borderRadius: "7px",
    boxShadow: "5px 6px 25px 3px rgba(0, 0, 0, 0.3)",
    borderTopLeftRadius: "7px",
    borderBottomLeftRadius: "7px",
    borderLeft: "7px white solid",
    "&:hover": {
      borderLeft: "7px rgb(199,241,144) solid",
    },
    [theme.breakpoints.down("sm")]: {
      margin: "22px 0",
    },
  },
}));

const Advertisements = () => {
  const classes = useStyles();
  const [getData, setGetData] = useState([]);

  const fetchData = () => {
    return axios
      .get("/advertisements")
      .then((res) => {
        setGetData(res.data);
      })
      .catch((err) => console.log("err=> ", err));
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <Box>
      <Box py={4} textAlign="center">
        <Typography variant="h4">Découvrez les offres d’emploi</Typography>
      </Box>
      <Box px={1} py={2}>
        {getData.map((item) => (
          <Box className={classes.root} key={item.id}>
            <AllAdvertisements item={item} />
          </Box>
        ))}
      </Box>
    </Box>
  );
};

export default Advertisements;
