import React, { useState, useEffect } from "react";
import { Box, Typography } from "@material-ui/core";
import axios from "axios";
import UserApply from "../../Components/Client/UserApply";

const UserID = JSON.parse(localStorage.getItem("id")) || "";
const getUserID = UserID.id || "";

const AdvertisementsClient = () => {
  const [valuesApplys, setValuesApplys] = useState([]);

  const fetchDataApply = () => {
    return axios
      .post(`/user-apply/${getUserID}`, { getUserID })
      .then((res) => setValuesApplys(res.data))
      .catch((err) => console.log("Error fetchDataApply", err));
  };

  useEffect(() => {
    fetchDataApply();
  }, []);

  return (
    <Box py={4}>
      <Box textAlign="center">
        <Typography variant="h4">Mes candidature(s)</Typography>
      </Box>
      <Box>
        <UserApply valuesApplys={valuesApplys} getUserID={getUserID} />
      </Box>
    </Box>
  );
};

export default AdvertisementsClient;
