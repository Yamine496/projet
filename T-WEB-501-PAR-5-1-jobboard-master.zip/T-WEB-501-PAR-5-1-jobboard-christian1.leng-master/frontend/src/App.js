import {
  BrowserRouter as Router,
  Switch,
  Route,
  Redirect,
} from "react-router-dom";
import { ThemeProvider } from "@mui/material/styles";
import { jobboardTheme } from "./style/theme";
import JobBoardRoute from "./Layout/JobBoardRoute";
import Companies from "./Views/Companies";
import Advertisements from "./Views/Advertisements";
import Connexion from "./Views/Connexion";
import Inscription from "./Views/Inscription";
import Profile from "./Views/Profile";
import CreateAdvertisement from "./Views/Recruteur/CreateAdvertisement";
import AllAdvertisements from "./Views/Recruteur/AllAdvertisements";
import AdvertisementsClient from "./Views/Client/AdvertisementsClient";
import AdminUsers from "./Views/Admin/AdminUsers";
import AdminAdvertisements from "./Views/Admin/AdminAdvertisements";
import Header from "../src/Views/Header";

const UserRole = JSON.parse(localStorage.getItem("role")) || "";
const getUserRole = UserRole.getRole || "";

const App = () => {
  return (
    <ThemeProvider theme={jobboardTheme}>
      <Router>
        <Header />
        <Switch>
          <Route exact path="/" component={Advertisements} />
          <Route exact path="/advertisements" component={Advertisements} />
          <Route exact path="/companies" component={Companies} />
          <Route exact path="/connexion" component={Connexion} />
          <Route exact path="/inscription" component={Inscription} />
          <JobBoardRoute
            exact
            path="/create-advertisement"
            component={CreateAdvertisement}
          />
          <JobBoardRoute
            exact
            path="/all-advertisement"
            component={AllAdvertisements}
          />
          <JobBoardRoute
            exact
            path="/advertisements-client"
            component={AdvertisementsClient}
          />
          <JobBoardRoute exact path="/profile" component={Profile} />
          {getUserRole === "ADMIN" ? (
            <>
              <JobBoardRoute exact path="/admin-user" component={AdminUsers} />
              <JobBoardRoute
                exact
                path="/admin-ad"
                component={AdminAdvertisements}
              />
            </>
          ) : (
            <Redirect
              to={{
                pathname: "/",
              }}
            />
          )}
        </Switch>
      </Router>
    </ThemeProvider>
  );
};

export default App;
